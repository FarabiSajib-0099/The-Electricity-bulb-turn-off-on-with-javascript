
/*var shohel= 4,
    akash= 5,
    tipu =5,
    sojib =6,
    mahmud= 7;

    alert(shohel+akash);
    */
  /*var x =1;
   while(x<10){
       document.write("<br/>ami tomake valobashi="+x);
       x++;
   }
  
*/
function clock(){
var hours =document.getElementById('hour');
var minutes =document.getElementById('minutes');
var seconds =document.getElementById('seconds');

var h =new Date().getHours();
var m =new Date().getMinutes();
var s =new Date().getSeconds();


hours.innerHTML=h;
minutes.innerHTML=m;
seconds.innerHTML=s;
}
var interval = setInterval(clock,1000);